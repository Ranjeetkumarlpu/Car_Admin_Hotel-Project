<?php 
require_once("../config/db.php");
error_reporting(0);
$f_fuel_type=$_GET['d2'];
?>
<select class="form-control" name="fuel_type">
    <option>----Select fuel type -----</option>
    <?php 
    
				 				$data1=mysqli_query($way,"SELECT * FROM `fuel_type` WHERE `modal`='$f_fuel_type'");
				 				while($row1=mysqli_fetch_array($data1,MYSQLI_ASSOC))
				 				{
				 					$fuel_type=$row1['fuel_type'];
				 					echo "<option value='$fuel_type'>$fuel_type</option>";
				 				}

				 		?>
</select>