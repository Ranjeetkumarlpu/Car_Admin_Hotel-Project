<?php 
require_once("../config/db.php");
error_reporting(0);
$b_modal=$_GET['d2'];
?>
<select class="form-control" name="modal" onchange="getfueltype(this.value)">
    <option>----Select Modal -----</option>
    <?php 
    
				 				$data1=mysqli_query($way,"SELECT * FROM `modals` WHERE `year`='$b_modal'");
				 				while($row1=mysqli_fetch_array($data1,MYSQLI_ASSOC))
				 				{
				 					$modal=$row1['modal'];
				 					echo "<option value='$modal'>$modal</option>";
				 				}

				 		?>
</select>