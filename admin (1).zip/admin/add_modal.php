<?php 
include ('all_link.php');
?>
<div class="container-fluid">
    <?php include ('sidebar.php');?>
    <div class="split_right" style="background-color:white">
        <?php 
require_once("../config/db.php");
error_reporting(0);
if($_POST['add_modal'])
{
    $brand=$_POST['brand'];
    $year=$_POST['year'];
    $modal=$_POST['modal'];

    if($brand=="----Select Brand -----")
    {
        echo "Select Brand first";
    }
    elseif($year=="----Select year -----")
{
    echo "Select year first";
}
    else
    {
        if(mysqli_query($way,"INSERT INTO `modals`(`brand_name`,`year`, `modal`) VALUES ('$brand','$year','$modal')"))
        {
            echo "modal Added";
        }
        else
        {
            echo "Try gain";
        }
    }
}


?>
        <div class="container">
            <div class="row">
                <div class="col-md-3"></div>
                <div class="col-md-6">
                    <form method="post">
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Select Brand</label>
                            <select class="form-control" name="brand" onchange="getyear(this.value)">
                                <option>----Select Brand -----</option>
                                <?php  
                                    $data=mysqli_query($way,"SELECT * FROM `brands`");
                                    while ($row=mysqli_fetch_array($data,MYSQLI_ASSOC)) {
                                        $brand_name=$row['brand_name'];

                                        ?>
                                <option value="<?php echo $brand_name; ?>"><?php echo $brand_name; ?></option>
                                <?php
                                    }
                             ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Select year</label>
                            <div class="col">
                                <div id="result"></div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Add modal</label>
                            <input type="text" class="form-control" id="formGroupExampleInput" name="modal">
                        </div>
                        <div class="mb-3">
                            <input type="submit" name="add_modal" value="Add modal">
                        </div>
                    </form>
                </div>
                <div class="col-md-3"></div>
            </div>
        </div>
        <script type="text/javascript">
        function getyear(year) {

            // alert(year);


            var ajaxRequest; // The variable that makes Ajax possible!
            try {
                // Opera 8.0+, Firefox, Safari
                ajaxRequest = new XMLHttpRequest();
            } catch (e) {
                // Internet Explorer Browsers
                try {
                    ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
                } catch (e) {
                    try {
                        ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
                    } catch (e) {
                        // Something went wrong
                        alert("Your browser broke!");
                        return false;
                    }
                }
            }

            // Create a function that will receive data
            // sent from the server and will update
            // div section in the same page.
            ajaxRequest.onreadystatechange = function() {
                if (ajaxRequest.readyState == 4) {
                    var ajaxDisplay = document.getElementById('result');
                    ajaxDisplay.innerHTML = ajaxRequest.responseText;
                }
            }

            // Now get the value from user and pass it to
            // server script.
            // var email = document.getElementById('email').value;
            //this ? string is neccessary for pass value.
            // var sea=document.getElementById('val').value;
            //var d2 = document.getElementById('d2').value;
            // var queryString1 ="?d1=" + d1 + "&d2=" + d2; 
            var queryString1 = "?d1=" + year;
            //alert(queryString1);
            // location.reload();
            ajaxRequest.open("GET", "get_year.php" + queryString1, true);
            //  location.reload();
            ajaxRequest.send(null);
            // document.getElementById('dispay_result').innerHTML=sea;

        }
        </script>
    </div>
</div>