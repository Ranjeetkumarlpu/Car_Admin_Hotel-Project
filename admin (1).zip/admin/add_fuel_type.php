<?php include ('all_link.php');?>
<div class="container-fluid">
    <?php include ('sidebar.php');?>
    <div class="split_right" style="background-color:white">
        <?php 
require_once("../config/db.php");
error_reporting(0);
if($_POST['add_fuel_type'])
{
    $brand=$_POST['brand'];
    $year=$_POST['year'];
    $modal=$_POST['modal'];
    $fuel_type=$_POST['fuel_type'];

    if($brand=="----Select Brand -----")
    {
        $msg="Select Brand first";
        // echo "Select Brand first";
    }
    elseif($year=="----Select year -----")
{
    $msg="Select year first";
}
elseif($modal=="----Select Modal -----")
{
     $msg="Select modal first";
}
    else
    {
        if(mysqli_query($way,"INSERT INTO `fuel_type`(`brand_name`,`year`, `modal`, `fuel_type`) VALUES ('$brand','$year','$modal','$fuel_type')"))
        {
             $msg="$fuel_type Added";
        }
        else
        {
             $msg="Try gain";
        }
    }
}


?>
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                </div>
                <div class="col-md-6">
                    <form method="post">
                        <div class="mb-3">
                            <?php   
                                if(isset($msg))
                                {
                            ?>
                            <div class="alert alert-success">
                                <?php echo $msg; ?>
                            </div>
                            <?php
                            }
                            ?>
                            <label for="formGroupExampleInput" class="form-label">Select Brand</label>
                            <select class="form-control" name="brand" onchange="getyear(this.value)">
                                <option>----Select Brand -----</option>
                                <?php  
                                    $data=mysqli_query($way,"SELECT * FROM `brands`");
                                    while ($row=mysqli_fetch_array($data,MYSQLI_ASSOC)) {
                                        $brand_name=$row['brand_name'];

                                        ?>
                                <option value="<?php echo $brand_name; ?>"><?php echo $brand_name; ?></option>
                                <?php
                                    }
                             ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Select year</label>
                            <div class="col">
                                <div id="result1"></div>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Select Modal</label>
                            <div class="col">
                                <div id="result2"></div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Add Fuel Type</label>
                            <input type="text" class="form-control" id="formGroupExampleInput" name="fuel_type">
                        </div>
                        <div class="mb-3">
                            <input type="submit" name="add_fuel_type" value="Add Fuel Type">
                        </div>
                    </form>
                </div>
                <div class="col-md-3"></div>
            </div>
        </div>
        <script type="text/javascript">
        function getyear(year) {

            // alert(year);


            var ajaxRequest; // The variable that makes Ajax possible!
            try {
                // Opera 8.0+, Firefox, Safari
                ajaxRequest = new XMLHttpRequest();
            } catch (e) {
                // Internet Explorer Browsers
                try {
                    ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
                } catch (e) {
                    try {
                        ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
                    } catch (e) {
                        // Something went wrong
                        alert("Your browser broke!");
                        return false;
                    }
                }
            }

            // Create a function that will receive data
            // sent from the server and will update
            // div section in the same page.
            ajaxRequest.onreadystatechange = function() {
                if (ajaxRequest.readyState == 4) {
                    var ajaxDisplay = document.getElementById('result1');
                    ajaxDisplay.innerHTML = ajaxRequest.responseText;
                }
            }

            // Now get the value from user and pass it to
            // server script.
            // var email = document.getElementById('email').value;
            //this ? string is neccessary for pass value.
            // var sea=document.getElementById('val').value;
            //var d2 = document.getElementById('d2').value;
            // var queryString1 ="?d1=" + d1 + "&d2=" + d2; 
            var queryString1 = "?d1=" + year;
            //alert(queryString1);
            // location.reload();
            ajaxRequest.open("GET", "get_year.php" + queryString1, true);
            //  location.reload();
            ajaxRequest.send(null);
            // document.getElementById('dispay_result1').innerHTML=sea;

        }



        function getmodal(fuel_type) {

            // alert(fuel_type);


            var ajaxRequest; // The variable that makes Ajax possible!
            try {
                // Opera 8.0+, Firefox, Safari
                ajaxRequest = new XMLHttpRequest();
            } catch (e) {
                // Internet Explorer Browsers
                try {
                    ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
                } catch (e) {
                    try {
                        ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
                    } catch (e) {
                        // Something went wrong
                        alert("Your browser broke!");
                        return false;
                    }
                }
            }

            // Create a function that will receive data
            // sent from the server and will update
            // div section in the same page.
            ajaxRequest.onreadystatechange = function() {
                if (ajaxRequest.readyState == 4) {
                    var ajaxDisplay = document.getElementById('result2');
                    ajaxDisplay.innerHTML = ajaxRequest.responseText;
                }
            }

            // Now get the value from user and pass it to
            // server script.
            // var email = document.getElementById('email').value;
            //this ? string is neccessary for pass value.
            // var sea=document.getElementById('val').value;
            //var d2 = document.getElementById('d2').value;
            // var queryString1 ="?d1=" + d1 + "&d2=" + d2; 
            var queryString1 = "?d2=" + fuel_type;
            //alert(queryString1);
            // location.reload();
            ajaxRequest.open("GET", "get_modal.php" + queryString1, true);
            //  location.reload();
            ajaxRequest.send(null);
            // document.getElementById('dispay_result2').innerHTML=sea;

        }
        </script>
    </div>
</div>