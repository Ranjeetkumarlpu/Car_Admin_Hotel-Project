<?php 
require_once("../config/db.php");
error_reporting(0);
$b_year=$_GET['d1'];
?>
<select class="form-control" name="year" onchange="getmodal(this.value)">
    <option>----Select year -----</option>
    <?php 
    
				 				$data1=mysqli_query($way,"SELECT * FROM `year` WHERE `brand_name`='$b_year'");
				 				while($row1=mysqli_fetch_array($data1,MYSQLI_ASSOC))
				 				{
				 					$year=$row1['year'];
				 					echo "<option value='$year'>$year</option>";
				 				}

				 		?>
</select>