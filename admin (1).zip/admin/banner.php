<?php include ('all_link.php');?>
<div class="container-fluid">
    <?php include ('sidebar.php');?>
    <div class="split_right" style="background-color:white">
        <?php 

require_once("../config/db.php");
error_reporting(0);
extract($_POST);
if(isset($banner))
{
        // 	echo "<pre>";
        // 	print_r($_POST);

         $name=$_FILES['b_pic']['name'];
         $temp=$_FILES['b_pic']['tmp_name'];

         $ext=end(explode(".", $name));

        if($ext=="jpg" or $ext=="png")
        {
            $b_pic=rand(99999,999999);

            $f_pic=$b_pic.".jpg";

            $upload="../assets/uploads/$f_pic";
            $upload1="assets/uploads/$f_pic";
             move_uploaded_file($_FILES["p_pic"]["tmp_name"][$key],$upload);

            if(move_uploaded_file($temp, "../assets/uploads/$f_pic"))
            {
                $sql="INSERT INTO `banners`(`banner_heading`,`banner_text`,`banner_pic`) VALUES ('$banner_heading','$banner_text','$upload1')";
                if(mysqli_query($way,$sql))
  	 			{
  	 				header("location:banner.php");
                       $msg="banner Inserted Successfully !";
				}  	 					
                else
  	 				
                {
  	 				$msg="Record Not Inserted !";	
                }
            }
            else
            {
                $msg="Upload first banner";
            }             

        }
        else
        {
            $msg="Must be upload  banner picture";
        }

         
}

?>
        <form method="post" enctype="multipart/form-data">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <?php   

  	   						if(isset($msg))
  	   						{
  	   							?>
                        <div class="alert alert-success">
                            <?php echo $msg; ?>
                        </div>
                        <?php
  	   						}

  	   				?>

                    </div>
                </div>
                <div class="row">
                    <div class="col-md-3"></div>
                    <div class="col-md-6">
                        <form method="post" enctype="multipart/form-data">
                            <div class="mb-3">
                                <label for="formGroupExampleInput" class="form-label">Add Banner Hadding</label>
                                <input type="text" class="form-control" id="formGroupExampleInput"
                                    name="banner_heading">
                            </div>

                            <div class="mb-3">
                                <label for="formGroupExampleInput" class="form-label">Add Banner Text</label>
                                <input type="text" class="form-control" id="formGroupExampleInput" name="banner_text">
                            </div>

                            <div class="mb-3">
                                <label for="formGroupExampleInput" class="form-label">Add Banner</label>
                                <input type="file" class="form-control" id="formGroupExampleInput" name="b_pic">
                            </div>
                            <div class="mb-3">
                                <input type="submit" name="banner" value="Add Menu">
                            </div>
                        </form>
                    </div>
                    <div class="col-md-3"></div>
                </div>
            </div>
        </form>
    </div>
</div>