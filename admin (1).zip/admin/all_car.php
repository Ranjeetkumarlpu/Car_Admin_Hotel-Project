<?php include ('all_link.php');?>
<div class="container-fluid">
    <?php include ('sidebar.php');?>
    <div class="split_right" style="background-color:white">
        <table class="table table-dark table-striped">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">brand_name</th>
                    <th scope="col">year</th>
                    <th scope="col">modal</th>
                    <th scope="col">fuel_type</th>
                    <th scope="col">no_plate</th>
                    <th scope="col">chassis_no</th>
                    <th scope="col">gear_box</th>
                    <th scope="col">color</th>
                    <th scope="col">price</th>
                    <th scope="col">car_des</th>
                    <th scope="col">image</th>
                    <th scope="col">operations</th>
                </tr>
            </thead>
            <tbody>

                <?php
                $sql="SELECT * FROM `cars`";
                $result=mysqli_query($way,$sql);
                if ($result) 
                {
                    while( $row=mysqli_fetch_assoc($result))
                    {
                        $id=$row['car_id'];
                        $brand_name=$row['brand_name'];
                        $year=$row['year'];
                        $modal=$row['modal'];
                        $fuel_type=$row['fuel_type'];
                        $no_plate=$row['no_plate'];
                        $chassis_no=$row['chassis_no'];
                        $gear_box=$row['gear_box'];
                        $color=$row['color'];
                        $price=$row['price'];
                        $car_des=$row['car_des'];
                       
                        
                        $data5=mysqli_query($way,"SELECT `car_image_name` FROM `car_image` 
                        WHERE `car_ref_id`='$id' ORDER BY img_id asc LIMIT 1");
                        $row5=mysqli_fetch_array($data5,MYSQLI_ASSOC);
                        $car_image_name=$row5['car_image_name'];


                        ?>
                <tr>
                    <th scope="row"><?php echo $id;?></th>
                    <td><?php echo $brand_name;?></td>
                    <td><?php echo $year;?></td>
                    <td><?php echo $modal;?></td>
                    <td><?php echo $fuel_type;?></td>
                    <td><?php echo $no_plate;?></td>
                    <td><?php echo $chassis_no;?></td>
                    <td><?php echo $gear_box;?></td>
                    <td><?php echo $color;?></td>
                    <td><?php echo $price;?></td>
                    <td><?php echo $car_des;?></td>
                    <td><img src="../<?php echo $car_image_name;?>" alt="" style="width:100;"></td>
                    <td>
                        <button class="btn btn-primary"><a href="update.php?updateid=<?php echo $id; ?>"
                                class="text-light">Update</a></button>
                        <button class="btn btn-danger"><a href="delete.php?deleteid=<?php echo $id; ?>"
                                class="text-light">Delete</a></button>
                    </td>

                </tr>
                <?php
					}
                }
				?>

            </tbody>
        </table>
    </div>
</div>
</div>