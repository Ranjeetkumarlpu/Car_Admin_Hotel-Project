<?php include ('all_link.php');?>
<div class="container-fluid">
    <?php include ('sidebar.php');?>
    <div class="split_right" style="background-color:white">
        <?php 
require_once("../config/db.php");
error_reporting(0);
if($_POST['add_year'])
{
    $brand=$_POST['brand'];
    $year=$_POST['year'];

    if($brand=="----Select Brand -----")
    {
        echo "Select Brand first";
    }
    
    else
    {

        if(mysqli_query($way,"INSERT INTO `year`(`brand_name`, `year`) VALUES ('$brand','$year')"))
        {
            echo "Year Added";
        }
        else
        {
            echo "Try again";
        }
    }
}


?>
        <div class="container">
            <div class="row">
                <div class="col-md-3"></div>
                <div class="col-md-6">
                    <form method="post">
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Select Brand</label>
                            <select class="form-control" name="brand">
                                <option>----Select Brand -----</option>
                                <?php  
                                    $data=mysqli_query($way,"SELECT * FROM `brands`");
                                    while ($row=mysqli_fetch_array($data,MYSQLI_ASSOC)) {
                                        $brand_name=$row['brand_name'];

                                        ?>
                                <option value="<?php echo $brand_name; ?>"><?php echo $brand_name; ?></option>
                                <?php
                                    }
                             ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Add Year</label>
                            <input type="text" class="form-control" id="formGroupExampleInput" name="year">
                        </div>
                        <div class="mb-3">
                            <input type="submit" name="add_year" value="Add Year">
                        </div>
                    </form>
                </div>
                <div class="col-md-3"></div>
            </div>
        </div>
    </div>
</div>