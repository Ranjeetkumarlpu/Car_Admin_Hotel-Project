<?php include ('all_link.php');?>
<div class="container-fluid">
    <?php include ('sidebar.php');?>
    <div class="split_right" style="background-color:white">
        <?php  

            require_once("../config/db.php");
            error_reporting(0);
            extract($_POST);
            if(isset($add_car))
            {
                // echo "<pre>";
                // print_r($_POST);

                $sql="INSERT INTO `cars`(`brand_name`, `year`, `modal`, `fuel_type`, `no_plate`, `chassis_no`, `gear_box`, `color`, `price`, `car_des`) VALUES ('$brand',  '$year','$modal','$fuel_type','$no_plate','$chassis_no','$gear_box','$color','$price','$car_des')";

                if(mysqli_query($way,$sql))
                {
                    // echo "Car addedd";
                        $data3=mysqli_query($way,"SELECT `car_id` FROM `cars` order by car_id desc LIMIT 1");
                        $row3=mysqli_fetch_array($data3,MYSQLI_ASSOC);
                        $last_id=$row3['car_id'];
                        foreach($_FILES["c_pic"]["tmp_name"] as $key=>$tmp_name)
                                {
                                $file_name=$_FILES["c_pic"]["name"][$key];
                                // echo $file_name."<br/>";
                                $upload="../assets/pro_pic/$file_name";
                                $upload1="assets/pro_pic/$file_name";
                                move_uploaded_file($_FILES["c_pic"]["tmp_name"][$key],$upload);
                                    mysqli_query($way,"INSERT INTO `car_image`(`car_ref_id`, `car_image_name`) VALUES ($last_id,'$upload1')");
                                
                                
                                }
                                $msg="Car Inserted Successfully !";
                }
                else
                {
                    $msg="Try again";
                }


            }

        ?>
        <div class="row">
            <div class="col-md-12">
                <div style="text-align: center; font-size: 26px;">
                    Add Cars
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-3">
            </div>
            <div class="col-md-6">
                <?php   
                                if(isset($msg))
                                {
                            ?>
                <div class="alert alert-success">
                    <?php echo $msg; ?>
                </div>
                <?php
                            }
                            ?>
                <form method="post" enctype="multipart/form-data">
                    <div class="row" style="margin-top: 2%;">
                        <div class="col">
                            <select class="form-control" name="brand" onchange="getyear(this.value)">
                                <option>----Select brand----</option>
                                <?php 
				 				$data=mysqli_query($way,"SELECT * FROM `brands`");
				 				while($row=mysqli_fetch_array($data,MYSQLI_ASSOC))
				 				{
				 					$brand_name=$row['brand_name'];
				 					echo "<option value='$brand_name'>$brand_name</option>";
				 				}

				 		?>
                            </select>
                        </div>
                    </div>
                    <div class="row" style="margin-top: 2%;">
                        <div class="col">
                            <div id="result"></div>
                        </div>
                    </div>

                    <div class="row" style="margin-top: 2%;">
                        <div class="col">
                            <div id="result2"></div>
                        </div>
                    </div>

                    <div class="row" style="margin-top: 2%;">
                        <div class="col">
                            <div id="result3"></div>
                        </div>
                    </div>

                    <div class="row" style="margin-top: 2%;">
                        <div class="col">
                            <input type="text" name="no_plate" class="form-control" placeholder="Car No Plate">
                        </div>
                    </div>

                    <div class="row" style="margin-top: 2%;">
                        <div class="col">
                            <input type="text" name="chassis_no" class="form-control" placeholder="Car Chassis No">
                        </div>
                        <div class="col">
                            <input type="text" name="gear_box" class="form-control" placeholder="Car Gear Box">
                        </div>
                    </div>

                    <div class="row" style="margin-top: 2%;">
                        <div class="col">
                            <input type="text" name="color" class="form-control" placeholder="Car Color">
                        </div>
                        <div class="col">
                            <input type="text" name="price" class="form-control" placeholder="Car Price">
                        </div>
                    </div>

                    <div class="row" style="margin-top: 2%;">
                        <div class="col">
                            <textarea class="form-control" style="height:80px" placeholder="Car Description"
                                name="car_des"></textarea>
                        </div>

                    </div>

                    <div class="row" style="margin-top: 2%;">
                        <div class="col">
                            <input type="file" name="c_pic[]" multiple>
                        </div>
                    </div>

                    <div class="row" style="margin-top: 2%;margin-bottom: 5%;">
                        <div class="col" align="center">
                            <input type="submit" name="add_car" class="btn btn-primary" value="Add Car">
                        </div>

                    </div>
                </form>
            </div>
            <div class="col-md-3">
            </div>

        </div>
    </div>

    <script type="text/javascript">
    function getyear(year) {

        // alert(year);


        var ajaxRequest; // The variable that makes Ajax possible!
        try {
            // Opera 8.0+, Firefox, Safari
            ajaxRequest = new XMLHttpRequest();
        } catch (e) {
            // Internet Explorer Browsers
            try {
                ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
            } catch (e) {
                try {
                    ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
                } catch (e) {
                    // Something went wrong
                    alert("Your browser broke!");
                    return false;
                }
            }
        }

        // Create a function that will receive data
        // sent from the server and will update
        // div section in the same page.
        ajaxRequest.onreadystatechange = function() {
            if (ajaxRequest.readyState == 4) {
                var ajaxDisplay = document.getElementById('result');
                ajaxDisplay.innerHTML = ajaxRequest.responseText;
            }
        }

        // Now get the value from user and pass it to
        // server script.
        // var email = document.getElementById('email').value;
        //this ? string is neccessary for pass value.
        // var sea=document.getElementById('val').value;
        //var d2 = document.getElementById('d2').value;
        // var queryString1 ="?d1=" + d1 + "&d2=" + d2; 
        var queryString1 = "?d1=" + year;
        //alert(queryString1);
        // location.reload();
        ajaxRequest.open("GET", "get_year.php" + queryString1, true);
        //  location.reload();
        ajaxRequest.send(null);
        // document.getElementById('dispay_result').innerHTML=sea;

    }

    function getmodal(modal) {

        // alert(modal);


        var ajaxRequest; // The variable that makes Ajax possible!
        try {
            // Opera 8.0+, Firefox, Safari
            ajaxRequest = new XMLHttpRequest();
        } catch (e) {
            // Internet Explorer Browsers
            try {
                ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
            } catch (e) {
                try {
                    ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
                } catch (e) {
                    // Something went wrong
                    alert("Your browser broke!");
                    return false;
                }
            }
        }

        // Create a function that will receive data
        // sent from the server and will update
        // div section in the same page.
        ajaxRequest.onreadystatechange = function() {
            if (ajaxRequest.readyState == 4) {
                var ajaxDisplay = document.getElementById('result2');
                ajaxDisplay.innerHTML = ajaxRequest.responseText;
            }
        }

        // Now get the value from user and pass it to
        // server script.
        // var email = document.getElementById('email').value;
        //this ? string is neccessary for pass value.
        // var sea=document.getElementById('val').value;
        //var d2 = document.getElementById('d2').value;
        // var queryString1 ="?d1=" + d1 + "&d2=" + d2; 
        var queryString1 = "?d2=" + modal;
        //alert(queryString1);
        // location.reload();
        ajaxRequest.open("GET", "get_modal.php" + queryString1, true);
        //  location.reload();
        ajaxRequest.send(null);
        // document.getElementById('dispay_result2').innerHTML=sea;

    }

    function getfueltype(fuel_type) {

        // alert(fuel_type);


        var ajaxRequest; // The variable that makes Ajax possible!
        try {
            // Opera 8.0+, Firefox, Safari
            ajaxRequest = new XMLHttpRequest();
        } catch (e) {
            // Internet Explorer Browsers
            try {
                ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
            } catch (e) {
                try {
                    ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
                } catch (e) {
                    // Something went wrong
                    alert("Your browser broke!");
                    return false;
                }
            }
        }

        // Create a function that will receive data
        // sent from the server and will update
        // div section in the same page.
        ajaxRequest.onreadystatechange = function() {
            if (ajaxRequest.readyState == 4) {
                var ajaxDisplay = document.getElementById('result3');
                ajaxDisplay.innerHTML = ajaxRequest.responseText;
            }
        }

        // Now get the value from user and pass it to
        // server script.
        // var email = document.getElementById('email').value;
        //this ? string is neccessary for pass value.
        // var sea=document.getElementById('val').value;
        //var d2 = document.getElementById('d2').value;
        // var queryString1 ="?d1=" + d1 + "&d2=" + d2; 
        var queryString1 = "?d2=" + fuel_type;
        //alert(queryString1);
        // location.reload();
        ajaxRequest.open("GET", "get_fuel_type.php" + queryString1, true);
        //  location.reload();
        ajaxRequest.send(null);
        // document.getElementById('dispay_result2').innerHTML=sea;

    }
    </script>
</div>
</div>