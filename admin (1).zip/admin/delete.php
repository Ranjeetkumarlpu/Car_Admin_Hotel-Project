<?php
require('../config/db.php');
if(isset($_GET['deleteid']))
{
    $id=$_GET['deleteid'];

    $sql="DELETE FROM `cars` WHERE car_id=$id";
    $result=mysqli_query($way,$sql);
    if($result)
    {
        $sql1="DELETE FROM `car_image` WHERE car_ref_id=$id";
        $result1=mysqli_query($way,$sql1);
        if ($result1) {
             // echo "Car addedd";
         
        header('location:all_car.php');
        echo "Deleted Successfull";
        }
        
    }
    else {
        {
            die(mysqli_error($way));
        }
    }
}
?>